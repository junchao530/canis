import logo from "./logo.svg";
import "./App.css";
import WorldMap from "./WorldMap";

function App() {
  return (
    <div className="App">
      <WorldMap />
    </div>
  );
}

export default App;
